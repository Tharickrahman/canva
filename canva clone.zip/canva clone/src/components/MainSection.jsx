import React from 'react'
import Content from './Content'

export default function MainSection() {
  return (
    <div className='main'>
      <p>Position</p>


      <div className="content-sec">
        <Content/>
      </div>
    </div>
  )
}
